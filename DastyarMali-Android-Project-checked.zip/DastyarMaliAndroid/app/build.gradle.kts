plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.imperialdesign.dastyarmali"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.imperialdesign.dastyarmali"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
