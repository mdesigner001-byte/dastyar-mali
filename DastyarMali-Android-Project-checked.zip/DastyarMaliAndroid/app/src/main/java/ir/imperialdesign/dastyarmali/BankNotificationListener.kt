package ir.imperialdesign.dastyarmali

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BankNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val packageName = sbn.packageName.lowercase()
        // Optional notification listener. Parsing is deliberately limited to notifications
        // that clearly identify Bank Melli; user must enable access in Android Settings.
        if (!packageName.contains("bank") && !packageName.contains("melli") && !packageName.contains("bmi")) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        val parsed = BankParser.parse(title, body)
        if (parsed != null) BankStore.addSuggestion(this, parsed)
    }
}
