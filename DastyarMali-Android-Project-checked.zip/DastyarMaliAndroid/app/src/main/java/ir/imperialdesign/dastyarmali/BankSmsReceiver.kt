package ir.imperialdesign.dastyarmali

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class BankSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (message in messages) {
            val parsed = BankParser.parse(message.originatingAddress.orEmpty(), message.messageBody.orEmpty())
            if (parsed != null) BankStore.addSuggestion(context, parsed)
        }
    }
}
