package ir.imperialdesign.dastyarmali

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object BankStore {
    private const val PREF = "bank_suggestions"
    private const val KEY = "items"
    @Synchronized fun addSuggestion(context: Context, item: JSONObject) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY, "[]"))
        // Keep the queue bounded and avoid filling storage with duplicate messages.
        for (i in 0 until arr.length()) {
            val old = arr.optJSONObject(i) ?: continue
            if (old.optString("raw") == item.optString("raw") &&
                old.optLong("createdAt") > System.currentTimeMillis() - 120_000L) return
        }
        arr.put(item)
        while (arr.length() > 50) arr.remove(0)
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
    @Synchronized fun getSuggestions(context: Context): JSONArray {
        return JSONArray(context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"))
    }
    @Synchronized fun removeSuggestion(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val old = JSONArray(prefs.getString(KEY, "[]"))
        val fresh = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("id") != id) fresh.put(item)
        }
        prefs.edit().putString(KEY, fresh.toString()).apply()
    }
}
