package ir.imperialdesign.dastyarmali

import org.json.JSONObject
import java.util.UUID

object BankParser {
    // Conservative parser: only creates a suggestion when the SMS contains a recognizable
    // transaction keyword and a labeled amount. It does not access bank accounts.
    fun parse(sender: String, body: String): JSONObject? {
        val text = body.replace(",", "").replace("٬", "").replace("،", "")
        val senderDigits = sender.filter { it.isDigit() }
        val isMelli = senderDigits.endsWith("700717") || sender.contains("بانک ملی") || sender.contains("ملی")
        if (!isMelli) return null

        val type = when {
            text.contains("واریز") || text.contains("دریافت") || text.contains("بستانکار") -> "income"
            text.contains("برداشت") || text.contains("انتقالی") || text.contains("حواله پل") || text.contains("خرید") -> "expense"
            else -> return null
        }
        val amountRegexes = listOf(
            Regex("""(?:مبلغ|مبلغ تراکنش|برداشت|واریز)\s*[:：]?\s*([0-9۰-۹]+)"""),
            Regex("""([0-9۰-۹]{4,})\s*(?:ریال|تومان)""")
        )
        var amountText: String? = null
        for (regex in amountRegexes) {
            amountText = regex.find(text)?.groupValues?.getOrNull(1)
            if (!amountText.isNullOrBlank()) break
        }
        if (amountText.isNullOrBlank()) return null
        val normalized = amountText!!.map { ch ->
            when (ch) {
                in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                else -> ch
            }
        }.joinToString("")
        val raw = normalized.toLongOrNull() ?: return null
        val toman = if (text.contains("تومان")) raw else raw / 10L
        if (toman <= 0L) return null
        val description = when {
            text.contains("حواله پل") -> "تراکنش بانکی: حواله پل"
            text.contains("انتقالی") -> "تراکنش بانکی: انتقال"
            text.contains("خرید") -> "تراکنش بانکی: خرید"
            type == "income" -> "تراکنش بانکی: واریز"
            else -> "تراکنش بانکی: برداشت"
        }
        return JSONObject()
            .put("id", UUID.randomUUID().toString())
            .put("type", type)
            .put("amount", toman)
            .put("description", description)
            .put("sender", sender)
            .put("raw", body.take(500))
            .put("createdAt", System.currentTimeMillis())
    }
}
