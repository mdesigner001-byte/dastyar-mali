plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "ir.imperial.financialassistant"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.imperial.financialassistant"
        minSdk = 26
        targetSdk = 32
        versionCode = 1
        versionName = "0.1.0"
    }
}
