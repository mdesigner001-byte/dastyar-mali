package ir.imperial.financialassistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

class BankNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        val big = extras.getCharSequence("android.bigText")?.toString().orEmpty()
        val body = listOf(title, text, big).filter { it.isNotBlank() }.joinToString(" — ")
        if (body.isBlank() || !BankParser.isBankMelliMessage(body)) return
        val parsed = BankParser.parse(body, sbn.postTime) ?: return
        val prefs = getSharedPreferences("bank_drafts", MODE_PRIVATE)
        val arr = try { org.json.JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { org.json.JSONArray() }
        val signature = "${parsed.type}|${parsed.amountRial}|${parsed.date.takeLast(5)}"
        val duplicate = (0 until arr.length()).any { i -> arr.optJSONObject(i)?.optString("signature") == signature }
        if (duplicate) return
        arr.put(
            JSONObject()
                .put("amount", parsed.amountToman)
                .put("amountRial", parsed.amountRial)
                .put("type", parsed.type)
                .put("date", parsed.date)
                .put("person", parsed.person)
                .put("note", parsed.note)
                .put("source", "اعلان بانک ملی")
                .put("signature", signature)
        )
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
