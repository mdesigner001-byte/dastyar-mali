package ir.imperial.financialassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject

class BankSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val prefs = context.getSharedPreferences("bank_drafts", Context.MODE_PRIVATE)
        val old = prefs.getString("items", "[]") ?: "[]"
        val arr = try { org.json.JSONArray(old) } catch (_: Exception) { org.json.JSONArray() }

        for (sms in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            val body = sms.messageBody ?: continue
            val sender = BankParser.normalizeDigits(sms.originatingAddress.orEmpty()).filter { it.isDigit() }
            // This build is intentionally limited to the short code and message format supplied by the user.
            if (sender != "700717" || !BankParser.isBankMelliMessage(body)) continue
            val parsed = BankParser.parse(body, sms.timestampMillis) ?: continue
            val signature = "${parsed.type}|${parsed.amountRial}|${parsed.date.takeLast(5)}"
            val duplicate = (0 until arr.length()).any { i ->
                val item = arr.optJSONObject(i)
                item?.optString("signature") == signature
            }
            if (duplicate) continue
            arr.put(
                JSONObject()
                    .put("amount", parsed.amountToman)
                    .put("amountRial", parsed.amountRial)
                    .put("type", parsed.type)
                    .put("date", parsed.date)
                    .put("person", parsed.person)
                    .put("note", parsed.note)
                    .put("source", "پیامک بانک ملی")
                    .put("signature", signature)
            )
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
