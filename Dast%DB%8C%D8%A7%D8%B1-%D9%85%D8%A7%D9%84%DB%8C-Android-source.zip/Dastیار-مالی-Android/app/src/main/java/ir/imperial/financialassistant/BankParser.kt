package ir.imperial.financialassistant

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Parser limited to the Bank Melli Iran SMS templates shared by the user. */
data class ParsedBankItem(
    val amountToman: Long,
    val amountRial: Long,
    val type: String,
    val date: String,
    val person: String,
    val note: String
)

object BankParser {
    fun normalizeDigits(input: String): String = input
        .replace('۰','0').replace('۱','1').replace('۲','2').replace('۳','3').replace('۴','4')
        .replace('۵','5').replace('۶','6').replace('۷','7').replace('۸','8').replace('۹','9')
        .replace('٠','0').replace('١','1').replace('٢','2').replace('٣','3').replace('٤','4')
        .replace('٥','5').replace('٦','6').replace('٧','7').replace('٨','8').replace('٩','9')

    private fun normalizeLetters(input: String): String = normalizeDigits(input)
        .replace('ي', 'ی').replace('ك', 'ک')
        .replace('\u200c', ' ')

    fun isBankMelliMessage(input: String): Boolean {
        val body = normalizeLetters(input).lowercase(Locale.ROOT)
        return body.contains("بانک ملی ایران") || body.contains("بانک ملی ايران") || body.contains("بانک ملی")
    }

    fun parse(input: String, timestamp: Long): ParsedBankItem? {
        val body = normalizeLetters(input)
        if (!isBankMelliMessage(body)) return null

        // Extract only the number attached to the transaction label, never account/balance numbers.
        val transaction = Regex(
            "(برداشت|انتقالی|انتقالي|حواله\\s*پل)\\s*[:：]\\s*([0-9]{1,3}(?:[,،][0-9]{3})+|[0-9]+)\\s*([+-])?",
            RegexOption.IGNORE_CASE
        ).find(body) ?: return null

        val label = transaction.groupValues[1].replace('ي', 'ی')
        val rawAmount = transaction.groupValues[2].replace(",", "").replace("،", "")
        val amountRial = rawAmount.toLongOrNull() ?: return null
        if (amountRial <= 0L) return null

        val sign = transaction.groupValues.getOrElse(3) { "" }
        val type = when {
            label == "برداشت" || sign == "-" -> "expense"
            label == "انتقالی" || label == "حواله پل" || sign == "+" -> "income"
            else -> "review"
        }
        val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("fa", "IR")).format(Date(timestamp))
        val amountToman = amountRial / 10L
        val note = "بانک ملی؛ ${label}؛ مبلغ پیامک به ریال تبدیل‌شده به تومان؛ قبل از ثبت بررسی کن"
        return ParsedBankItem(amountToman, amountRial, type, date, "تراکنش بانک ملی", note)
    }
}
