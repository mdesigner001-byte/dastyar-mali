package ir.imperial.financialassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView
import android.view.ViewGroup
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        status = TextView(this).apply { text = "دسترسی بانکی هنوز بررسی نشده است"; setPadding(16, 12, 16, 12); gravity = Gravity.CENTER; setTextColor(Color.DKGRAY) }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(Button(this).apply { text = "فعال‌سازی پیامک"; setOnClickListener { requestSms() } })
        controls.addView(Button(this).apply { text = "فعال‌سازی اعلان بانک"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } })
        root.addView(status, LinearLayout.LayoutParams(-1, -2)); root.addView(controls, LinearLayout.LayoutParams(-1, -2))
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient(); webChromeClient = WebChromeClient()
            addJavascriptInterface(BankBridge(), "BankBridge")
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f)); setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 12)
    }
    private fun requestSms() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS), 11)
        } else status.text = "مجوز پیامک فعال است؛ پیامک‌های بعدی بررسی می‌شوند."
    }
    override fun onResume() { super.onResume(); status.text = "پیامک: ${if (checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED) "فعال" else "خاموش"} | اعلان: از تنظیمات اعلان‌ها بررسی شود"; web.post { web.evaluateJavascript("consumePendingBankItems()", null) } }
    inner class BankBridge {
        @JavascriptInterface fun takePending(): String {
            val prefs = getSharedPreferences("bank_drafts", MODE_PRIVATE)
            val items = prefs.getString("items", "[]") ?: "[]"
            prefs.edit().putString("items", "[]").apply()
            return items
        }
        @JavascriptInterface fun saveDraft(json: String) { runOnUiThread { web.evaluateJavascript("window.addBankDraftFromNative(${org.json.JSONObject.quote(json)})", null) } }
    }
}
